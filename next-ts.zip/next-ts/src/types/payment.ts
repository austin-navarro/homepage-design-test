// ----------------------------------------------------------------------

export type IPaymentCard = {
  id: string;
  cardNumber: string;
  cardType: string;
  primary?: boolean;
};
