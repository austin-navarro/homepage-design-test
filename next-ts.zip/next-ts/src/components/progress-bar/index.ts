export { default } from './progress-bar';

export { default as StyledProgressBar } from './styles';
